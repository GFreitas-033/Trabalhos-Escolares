$(document).ready(function(){
    $('.tecla').click(function(e){
        e.preventDefault()
        let tecla = $(this).attr('id')
        console.log(tecla)
        $('#'+tecla).removeClass('tecla').addClass('mudaTeclaC')
    })
    
    $('.recomeca').click(function(e){
        e.preventDefault()
        location.reload()
    })
})