const socket = new WebSocket('ws://10.10.211.202:8080');// Ip da Maquina que está o servidor

socket.onopen = () => console.log('Conectado ao servidor.');

socket.onmessage = (event) => {
    const chat = document.getElementById('chat');
    const msg = document.createElement('p');
    msg.textContent = event.data;
    chat.appendChild(msg);
};

socket.onerror = (error) => console.error('Erro no WebSocket:', error);
socket.onclose = () => console.log('Conexão fechada.');

function enviarMensagem() {
    const mensagem = document.getElementById('mensagem').value;
    if (mensagem.trim() !== "" && socket.readyState === WebSocket.OPEN) {
        socket.send(mensagem);
        document.getElementById('mensagem').value = "";
    } else {
        alert('Conexão não está aberta ou mensagem vazia.');
    }
}