const WebSocket = require('ws');

const server = new WebSocket.Server({ port: 8080 });

server.on('connection', (socket) => {
    console.log('Cliente conectado.');

    socket.on('message', (message) => {
        console.log('Mensagem recebida:', message);
        
        // Enviar a mensagem para todos os clientes conectados
        server.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(`Mensagem: ${message}`);
            }
        });
    });

    socket.on('close', () => console.log('Cliente desconectado.'));
    socket.on('error', (error) => console.error('Erro no WebSocket:', error));
});

console.log('Servidor WebSocket rodando na porta 8080');