const express = require('express')
const app = express()
const port = 3000

app.get('/',(req,res)=>{
    res.status(200).send("Requisição Bem-Sucedida!")
})

app.get('/',(req,res)=>{
    res.status(404).send("Requisição Não Encontrada!")
})

app.get('/',(req,res)=>{
    res.status(500).send("Erro de Servidor!")
})

app.listen(port,()=>{
    console.log(`Server Started on Port ${port}`)
})