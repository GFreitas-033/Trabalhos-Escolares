package br.edu.fateclins.tap.feira.modelo;

public class ProdutorRural extends Pessoa{
    private String municipio;
    private String bairro;
    private String telefone;

    public ProdutorRural(String nome, String municipio, String bairro, String telefone) {
        super(nome);
        this.municipio = municipio;
        this.bairro = bairro;
        this.telefone = telefone;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getBairro() {
        return bairro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void souProdutor(){
        System.out.println("Nome: "+getNome());
        System.out.println("Município: "+getMunicipio());
        System.out.println("Bairro: "+getBairro());
        System.out.println("Telefone: "+getTelefone());
    }
}
