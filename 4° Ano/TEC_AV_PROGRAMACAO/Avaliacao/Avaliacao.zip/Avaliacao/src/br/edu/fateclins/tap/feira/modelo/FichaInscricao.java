package br.edu.fateclins.tap.feira.modelo;

public class FichaInscricao {
    private int numInscricao;
    private String tipoProduto;

    public FichaInscricao(int numInscricao, String tipoProduto) {
        this.numInscricao = numInscricao;
        this.tipoProduto = tipoProduto;
    }

    public int getNumInscricao() {
        return numInscricao;
    }

    public void setNumInscricao(int numInscricao) {
        this.numInscricao = numInscricao;
    }

    public String getTipoProduto() {
        return tipoProduto;
    }

    public void setTipoProduto(String tipoProduto) {
        this.tipoProduto = tipoProduto;
    }
}
