package br.edu.fateclins.tap.feira.modelo;

public class Produto {
    private String nomeProduto;
    private String variedade;
    private String nome;

    public Produto(String nomeProduto, String variedade, String nome) {
        this.nomeProduto = nomeProduto;
        this.variedade = variedade;
        this.nome = nome;
    }

    public String getNomeProduto() {
        return nomeProduto;
    }

    public void setNomeProduto(String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }

    public String getVariedade() {
        return variedade;
    }

    public void setVariedade(String variedade) {
        this.variedade = variedade;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void qualProduto(){
        System.out.println("Nome Produto: "+getNomeProduto());
        System.out.println("Variaedade: "+getVariedade());
        System.out.println("Nome do Produtor: "+getNome());
    }
}
