package br.edu.fateclins.tap.feira.modelo;

public class Juiz extends Pessoa {
    public Juiz(String nome) {
        super(nome);
    }

    public void souJuiz(){
        System.out.println("Sou um Juiz chamado: "+getNome());
    }
}
