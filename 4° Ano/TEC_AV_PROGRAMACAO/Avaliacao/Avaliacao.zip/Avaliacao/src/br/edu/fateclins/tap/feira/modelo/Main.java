package br.edu.fateclins.tap.feira.modelo;

public class Main {
    public static void main(String[] args) {
        ProdutorRural produtor1 = new ProdutorRural("Guilherme I",
                "Lins", "Algum", "(14)99999-9999");
        Produto produto1 = new Produto("Arroz",
                "preto?", produtor1.getNome());
        FichaInscricao ficha1 = new FichaInscricao(1, "Orgânico");
        Juiz juiz1 = new Juiz("Pazin");
        Julgamento julgamento1 = new Julgamento(ficha1.getNumInscricao(), juiz1.getNome()
                ,10, 9,8, 7,6,5);

        produtor1.souProdutor();
        System.out.println("");
        produto1.qualProduto();
        System.out.println("");
        julgamento1.resultado();
    }
}
