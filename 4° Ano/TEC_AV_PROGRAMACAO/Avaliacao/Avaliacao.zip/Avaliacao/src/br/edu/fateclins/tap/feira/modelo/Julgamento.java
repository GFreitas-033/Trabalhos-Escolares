package br.edu.fateclins.tap.feira.modelo;

public class Julgamento {
    private int numInsc;
    private String nomeJuiz;
    private float nota1;
    private float nota2;
    private float nota3;
    private float nota4;
    private float nota5;
    private float nota6;

    public Julgamento(int numInsc, String nomeJuiz, float nota1, float nota2, float nota3, float nota4, float nota5, float nota6) {
        this.numInsc = numInsc;
        this.nomeJuiz = nomeJuiz;
        this.nota1 = nota1;
        this.nota2 = nota2;
        this.nota3 = nota3;
        this.nota4 = nota4;
        this.nota5 = nota5;
        this.nota6 = nota6;
    }

    public String getNomeJuiz() {
        return nomeJuiz;
    }

    public void setNomeJuiz(String nomeJuiz) {
        this.nomeJuiz = nomeJuiz;
    }

    public int getNumInsc() {
        return numInsc;
    }

    public void setNumInsc(int numInsc) {
        this.numInsc = numInsc;
    }

    public float getNota1() {
        return nota1;
    }

    public void setNota1(float nota1) {
        this.nota1 = nota1;
    }

    public float getNota2() {
        return nota2;
    }

    public void setNota2(float nota2) {
        this.nota2 = nota2;
    }

    public float getNota3() {
        return nota3;
    }

    public void setNota3(float nota3) {
        this.nota3 = nota3;
    }

    public float getNota4() {
        return nota4;
    }

    public void setNota4(float nota4) {
        this.nota4 = nota4;
    }

    public float getNota5() {
        return nota5;
    }

    public void setNota5(float nota5) {
        this.nota5 = nota5;
    }

    public float getNota6() {
        return nota6;
    }

    public void setNota6(float nota6) {
        this.nota6 = nota6;
    }

    public void resultado(){
        System.out.println("Ficha de inscrição de número: "+getNumInsc());
        System.out.println("Juiz responsavel: "+getNomeJuiz());
        System.out.println("Critério 1 Nota: "+getNota1());
        System.out.println("Critério 2 Nota: "+getNota2());
        System.out.println("Critério 3 Nota: "+getNota3());
        System.out.println("Critério 4 Nota: "+getNota4());
        System.out.println("Critério 5 Nota: "+getNota5());
        System.out.println("Critério 6 Nota: "+getNota6());
    }
}
